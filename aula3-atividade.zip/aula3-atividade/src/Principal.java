
import aula3.atividade.LeituraRetornoBancoBradesco;
import aula3.atividade.LeituraRetornoBancoBrasil;
import aula3.atividade.ProcessarBoletos;
import java.net.URI;
import java.net.URISyntaxException;

public class Principal {

    public static void main(String[] args) throws URISyntaxException {

        final ProcessarBoletos processador = new ProcessarBoletos(new LeituraRetornoBancoBrasil());
        final ProcessarBoletos processador1 = new ProcessarBoletos(new LeituraRetornoBancoBradesco());

        URI caminhoArquivo = Principal.class.getResource("banco-brasil-1.csv").toURI();
        System.out.println("Lendo arquivo " + caminhoArquivo + "\n");

        URI caminhoArquivo1 = Principal.class.getResource("bradesco-1.csv").toURI();
        System.out.println("Lendo arquivo " + caminhoArquivo1 + "\n");

        processador.processar(caminhoArquivo);
    }
}
